(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a6191284._.js",
  "static/chunks/62955_next_dist_compiled_react-dom_89ced228._.js",
  "static/chunks/62955_next_dist_compiled_react-server-dom-turbopack_2690c13b._.js",
  "static/chunks/62955_next_dist_compiled_next-devtools_index_c25cd488.js",
  "static/chunks/62955_next_dist_compiled_c332f0d3._.js",
  "static/chunks/62955_next_dist_client_9b56777e._.js",
  "static/chunks/62955_next_dist_77c50b20._.js",
  "static/chunks/62955_@swc_helpers_cjs_2aa3c8c9._.js"
],
    source: "entry"
});
