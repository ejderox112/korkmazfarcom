(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_korkmazfarcom_src_app_headlight-list_tsx_44cceca8._.js",
  "static/chunks/62955_6ea5a1c5._.js",
  "static/chunks/Desktop_korkmazfarcom_src_app_page_tsx_a1fa69a1._.js"
],
    source: "dynamic"
});
