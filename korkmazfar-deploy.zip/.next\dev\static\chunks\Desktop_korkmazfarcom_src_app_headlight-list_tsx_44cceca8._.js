(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript, next/dynamic entry, async loader)", ((__turbopack_context__) => {

__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/Desktop_korkmazfarcom_src_app_headlight-list_tsx_65565a41._.js",
  "static/chunks/Desktop_korkmazfarcom_src_app_headlight-list_tsx_a909d679._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript, next/dynamic entry)");
    });
});
}),
]);