module.exports = [
"[project]/Desktop/korkmazfarcom/.next-internal/server/app/api/headlights/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=3d860_korkmazfarcom__next-internal_server_app_api_headlights_route_actions_3a5a31bb.js.map