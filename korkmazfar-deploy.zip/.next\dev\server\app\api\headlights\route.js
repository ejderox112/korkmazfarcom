var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/headlights/route.js")
R.c("server/chunks/62955_next_409a6b8a._.js")
R.c("server/chunks/[root-of-the-server]__75c5e35d._.js")
R.c("server/chunks/3d860_korkmazfarcom__next-internal_server_app_api_headlights_route_actions_3a5a31bb.js")
R.m("[project]/Desktop/korkmazfarcom/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/korkmazfarcom/src/app/api/headlights/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/Desktop/korkmazfarcom/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/Desktop/korkmazfarcom/src/app/api/headlights/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
