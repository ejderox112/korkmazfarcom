module.exports=[79824,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_korkmazfarcom__next-internal_server_app_page_actions_40dc7a3a.js.map