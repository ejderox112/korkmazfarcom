globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/62955_next_dist_build_polyfills_polyfill-nomodule.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_a6191284._.js",
    "static/chunks/62955_next_dist_compiled_react-dom_89ced228._.js",
    "static/chunks/62955_next_dist_compiled_react-server-dom-turbopack_2690c13b._.js",
    "static/chunks/62955_next_dist_compiled_next-devtools_index_c25cd488.js",
    "static/chunks/62955_next_dist_compiled_c332f0d3._.js",
    "static/chunks/62955_next_dist_client_9b56777e._.js",
    "static/chunks/62955_next_dist_77c50b20._.js",
    "static/chunks/62955_@swc_helpers_cjs_2aa3c8c9._.js",
    "static/chunks/Desktop_korkmazfarcom_a0ff3932._.js",
    "static/chunks/turbopack-Desktop_korkmazfarcom_8c3062e6._.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];