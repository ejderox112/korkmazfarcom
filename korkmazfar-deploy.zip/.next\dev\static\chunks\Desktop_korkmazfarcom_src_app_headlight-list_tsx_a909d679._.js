(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/Desktop_korkmazfarcom_src_app_headlight-list_tsx_65565a41._.js"
],
    source: "dynamic"
});
