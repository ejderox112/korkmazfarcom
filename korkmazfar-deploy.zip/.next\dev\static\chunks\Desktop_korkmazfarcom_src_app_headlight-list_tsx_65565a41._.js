(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>HeadlightList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/image.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function HeadlightList() {
    _s();
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(50);
    if ($[0] !== "045491128446411d7ad1c923776a5051fb8f6786fa445e25a2ecd8c4ccb7b6de") {
        for(let $i = 0; $i < 50; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "045491128446411d7ad1c923776a5051fb8f6786fa445e25a2ecd8c4ccb7b6de";
    }
    let t0;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = [];
        $[1] = t0;
    } else {
        t0 = $[1];
    }
    const [data, setData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(t0);
    const [search, setSearch] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [category, setCategory] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [geriAlan, setGeriAlan] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [durum, setDurum] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const priceFormatter = new Intl.NumberFormat("tr-TR");
    let t1;
    let t2;
    if ($[2] === Symbol.for("react.memo_cache_sentinel")) {
        t1 = ({
            "HeadlightList[useEffect()]": ()=>{
                fetch("/api/headlights").then(_HeadlightListUseEffectAnonymous).then(setData);
            }
        })["HeadlightList[useEffect()]"];
        t2 = [];
        $[2] = t1;
        $[3] = t2;
    } else {
        t1 = $[2];
        t2 = $[3];
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])(t1, t2);
    let t3;
    if ($[4] !== category || $[5] !== durum || $[6] !== geriAlan || $[7] !== search) {
        t3 = ({
            "HeadlightList[data.filter()]": (item)=>item.title.toLowerCase().includes(search.toLowerCase()) && (category ? item.category === category : true) && (geriAlan ? item.geriAlan === geriAlan : true) && (durum ? item.durum === durum : true)
        })["HeadlightList[data.filter()]"];
        $[4] = category;
        $[5] = durum;
        $[6] = geriAlan;
        $[7] = search;
        $[8] = t3;
    } else {
        t3 = $[8];
    }
    const filtered = data.filter(t3);
    const t4 = category && `Grup: ${category}`;
    const t5 = geriAlan && `Geri Alan: ${geriAlan}`;
    const t6 = durum && `Durum: ${durum}`;
    let t7;
    if ($[9] !== t4 || $[10] !== t5 || $[11] !== t6) {
        t7 = [
            t4,
            t5,
            t6
        ].filter(Boolean);
        $[9] = t4;
        $[10] = t5;
        $[11] = t6;
        $[12] = t7;
    } else {
        t7 = $[12];
    }
    const activeFilters = t7;
    let t8;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t8 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].h2, {
            className: "text-3xl font-bold text-blue-900 dark:text-blue-200 mb-6 text-center",
            initial: {
                opacity: 0,
                y: 30
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            viewport: {
                once: true
            },
            transition: {
                duration: 0.6
            },
            children: "\xDCr\xFCn Arama & Listeleme"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 86,
            columnNumber: 10
        }, this);
        $[13] = t8;
    } else {
        t8 = $[13];
    }
    let t9;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t9 = ({
            "HeadlightList[<input>.onChange]": (e)=>setSearch(e.target.value)
        })["HeadlightList[<input>.onChange]"];
        $[14] = t9;
    } else {
        t9 = $[14];
    }
    let t10;
    if ($[15] !== search) {
        t10 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Far, model veya marka ara...",
            className: "border rounded px-4 py-2 w-full md:w-60",
            value: search,
            onChange: t9
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 112,
            columnNumber: 11
        }, this);
        $[15] = search;
        $[16] = t10;
    } else {
        t10 = $[16];
    }
    let t11;
    let t12;
    let t13;
    let t14;
    let t15;
    if ($[17] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = ({
            "HeadlightList[<select>.onChange]": (e_0)=>setCategory(e_0.target.value)
        })["HeadlightList[<select>.onChange]"];
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "",
            children: "Tüm Ürün Grupları"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 127,
            columnNumber: 11
        }, this);
        t13 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Far Cam\u0131",
            children: "Far Camı"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 128,
            columnNumber: 11
        }, this);
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Far Kasas\u0131",
            children: "Far Kasası"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 129,
            columnNumber: 11
        }, this);
        t15 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Led Mod\xFCl",
            children: "Led Modül"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 130,
            columnNumber: 11
        }, this);
        $[17] = t11;
        $[18] = t12;
        $[19] = t13;
        $[20] = t14;
        $[21] = t15;
    } else {
        t11 = $[17];
        t12 = $[18];
        t13 = $[19];
        t14 = $[20];
        t15 = $[21];
    }
    let t16;
    if ($[22] !== category) {
        t16 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            className: "border rounded px-4 py-2 w-full md:w-48",
            value: category,
            onChange: t11,
            children: [
                t12,
                t13,
                t14,
                t15
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 145,
            columnNumber: 11
        }, this);
        $[22] = category;
        $[23] = t16;
    } else {
        t16 = $[23];
    }
    let t17;
    let t18;
    let t19;
    let t20;
    let t21;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t17 = ({
            "HeadlightList[<select>.onChange]": (e_1)=>setGeriAlan(e_1.target.value)
        })["HeadlightList[<select>.onChange]"];
        t18 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "",
            children: "Tümü (Orijinal/Çıkma/Yan Sanayi)"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 160,
            columnNumber: 11
        }, this);
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Orijinal",
            children: "Orijinal"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 161,
            columnNumber: 11
        }, this);
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "\xC7\u0131kma",
            children: "Çıkma"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 162,
            columnNumber: 11
        }, this);
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Yan Sanayi",
            children: "Yan Sanayi"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 163,
            columnNumber: 11
        }, this);
        $[24] = t17;
        $[25] = t18;
        $[26] = t19;
        $[27] = t20;
        $[28] = t21;
    } else {
        t17 = $[24];
        t18 = $[25];
        t19 = $[26];
        t20 = $[27];
        t21 = $[28];
    }
    let t22;
    if ($[29] !== geriAlan) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            className: "border rounded px-4 py-2 w-full md:w-40",
            value: geriAlan,
            onChange: t17,
            children: [
                t18,
                t19,
                t20,
                t21
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 178,
            columnNumber: 11
        }, this);
        $[29] = geriAlan;
        $[30] = t22;
    } else {
        t22 = $[30];
    }
    let t23;
    let t24;
    let t25;
    let t26;
    if ($[31] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = ({
            "HeadlightList[<select>.onChange]": (e_2)=>setDurum(e_2.target.value)
        })["HeadlightList[<select>.onChange]"];
        t24 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "",
            children: "Tümü (Yeni/İkinci El)"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 192,
            columnNumber: 11
        }, this);
        t25 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "Yeni",
            children: "Yeni"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 193,
            columnNumber: 11
        }, this);
        t26 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
            value: "\u0130kinci El",
            children: "İkinci El"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 194,
            columnNumber: 11
        }, this);
        $[31] = t23;
        $[32] = t24;
        $[33] = t25;
        $[34] = t26;
    } else {
        t23 = $[31];
        t24 = $[32];
        t25 = $[33];
        t26 = $[34];
    }
    let t27;
    if ($[35] !== durum) {
        t27 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
            className: "border rounded px-4 py-2 w-full md:w-40",
            value: durum,
            onChange: t23,
            children: [
                t24,
                t25,
                t26
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 207,
            columnNumber: 11
        }, this);
        $[35] = durum;
        $[36] = t27;
    } else {
        t27 = $[36];
    }
    let t28;
    if ($[37] !== t10 || $[38] !== t16 || $[39] !== t22 || $[40] !== t27) {
        t28 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col md:flex-row flex-wrap gap-4 mb-5 justify-center",
            children: [
                t10,
                t16,
                t22,
                t27
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 215,
            columnNumber: 11
        }, this);
        $[37] = t10;
        $[38] = t16;
        $[39] = t22;
        $[40] = t27;
        $[41] = t28;
    } else {
        t28 = $[41];
    }
    let t29;
    let t30;
    let t31;
    if ($[42] === Symbol.for("react.memo_cache_sentinel")) {
        t29 = {
            opacity: 0
        };
        t30 = {
            opacity: 1
        };
        t31 = {
            delay: 0.1
        };
        $[42] = t29;
        $[43] = t30;
        $[44] = t31;
    } else {
        t29 = $[42];
        t30 = $[43];
        t31 = $[44];
    }
    let t32;
    if ($[45] !== activeFilters) {
        t32 = activeFilters.map(_HeadlightListActiveFiltersMap);
        $[45] = activeFilters;
        $[46] = t32;
    } else {
        t32 = $[46];
    }
    const t33 = "grid grid-cols-1 md:grid-cols-3 gap-8";
    const t34 = filtered.length === 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "col-span-3 text-center text-zinc-500",
        children: "Sonuç bulunamadı."
    }, void 0, false, {
        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
        lineNumber: 254,
        columnNumber: 40
    }, this);
    const t35 = filtered.map({
        "HeadlightList[filtered.map()]": (item_0)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                className: "bg-white dark:bg-zinc-900 rounded-xl shadow p-5 flex flex-col items-center",
                whileHover: {
                    scale: 1.03
                },
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        src: item_0.image,
                        alt: item_0.title,
                        width: 120,
                        height: 80,
                        className: "mb-3 rounded"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 8
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "font-bold text-lg text-blue-800 dark:text-blue-200 mb-1",
                        children: item_0.title
                    }, void 0, false, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 104
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-zinc-600 dark:text-zinc-300 mb-1",
                        children: [
                            item_0.brand,
                            " ",
                            item_0.model,
                            " (",
                            item_0.year,
                            ")"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 197
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "text-blue-700 font-semibold mb-2",
                        children: [
                            priceFormatter.format(item_0.price),
                            " TL"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 303
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-xs px-2 py-1 rounded bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 mb-2",
                        children: [
                            item_0.category,
                            " / ",
                            item_0.geriAlan,
                            " / ",
                            item_0.durum
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 399
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        className: "mt-2 px-4 py-2 rounded bg-blue-700 text-white font-medium hover:bg-blue-800 transition",
                        children: "Detay"
                    }, void 0, false, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 258,
                        columnNumber: 571
                    }, this)
                ]
            }, item_0.id, true, {
                fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                lineNumber: 256,
                columnNumber: 48
            }, this)
    }["HeadlightList[filtered.map()]"]);
    let t36;
    if ($[47] !== t34 || $[48] !== t35) {
        t36 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: t33,
            children: [
                t34,
                t35
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
            lineNumber: 262,
            columnNumber: 11
        }, this);
        $[47] = t34;
        $[48] = t35;
        $[49] = t36;
    } else {
        t36 = $[49];
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "w-full max-w-5xl mx-auto py-12 px-4",
        children: [
            t8,
            t28,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-wrap gap-2 justify-center mb-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
                        className: "text-sm text-zinc-600 dark:text-zinc-300",
                        initial: t29,
                        animate: t30,
                        transition: t31,
                        children: [
                            filtered.length,
                            " ilan · ",
                            activeFilters.length ? "Filtreler" : "T\xFCm \xFCr\xFCnler"
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                        lineNumber: 269,
                        columnNumber: 134
                    }, this),
                    t32
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
                lineNumber: 269,
                columnNumber: 76
            }, this),
            t36
        ]
    }, void 0, true, {
        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
        lineNumber: 269,
        columnNumber: 10
    }, this);
}
_s(HeadlightList, "hiduVYSRhtxIycbrbHrnf4uctvM=");
_c = HeadlightList;
function _HeadlightListActiveFiltersMap(tag) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].span, {
        className: "px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-200 text-sm",
        initial: {
            opacity: 0,
            y: 10
        },
        animate: {
            opacity: 1,
            y: 0
        },
        transition: {
            duration: 0.2
        },
        children: tag
    }, tag, false, {
        fileName: "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx",
        lineNumber: 272,
        columnNumber: 10
    }, this);
}
function _HeadlightListUseEffectAnonymous(res) {
    return res.json();
}
var _c;
__turbopack_context__.k.register(_c, "HeadlightList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript, next/dynamic entry)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript)"));
}),
]);

//# sourceMappingURL=Desktop_korkmazfarcom_src_app_headlight-list_tsx_65565a41._.js.map