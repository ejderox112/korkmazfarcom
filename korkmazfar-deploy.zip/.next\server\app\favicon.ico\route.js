var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[externals]_next_dist_03fe02e0._.js")
R.c("server/chunks/[root-of-the-server]__6bcfc10c._.js")
R.c("server/chunks/62955_next_dist_esm_build_templates_app-route_403dd65d.js")
R.c("server/chunks/3d860_korkmazfarcom__next-internal_server_app_favicon_ico_route_actions_16657f7d.js")
R.m(85828)
module.exports=R.m(85828).exports
