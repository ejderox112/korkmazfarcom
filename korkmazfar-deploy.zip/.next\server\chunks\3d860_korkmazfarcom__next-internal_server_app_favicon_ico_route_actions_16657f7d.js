module.exports=[17090,(e,o,d)=>{}];

//# sourceMappingURL=3d860_korkmazfarcom__next-internal_server_app_favicon_ico_route_actions_16657f7d.js.map