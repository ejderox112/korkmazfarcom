module.exports=[69709,(a,b,c)=>{}];

//# sourceMappingURL=Desktop_korkmazfarcom__next-internal_server_app__not-found_page_actions_3ef79e15.js.map