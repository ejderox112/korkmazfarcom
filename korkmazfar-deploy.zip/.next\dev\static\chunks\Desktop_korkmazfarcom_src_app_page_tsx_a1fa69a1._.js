(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/Desktop/korkmazfarcom/src/app/page.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Home
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/compiled/react/compiler-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/image.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/framer-motion/dist/es/render/components/motion/proxy.mjs [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/Desktop/korkmazfarcom/node_modules/next/dist/shared/lib/app-dynamic.js [app-client] (ecmascript)");
;
"use client";
;
;
;
;
;
const HeadlightList = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$shared$2f$lib$2f$app$2d$dynamic$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"])(()=>__turbopack_context__.A("[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript, next/dynamic entry, async loader)"), {
    loadableGenerated: {
        modules: [
            "[project]/Desktop/korkmazfarcom/src/app/headlight-list.tsx [app-client] (ecmascript, next/dynamic entry)"
        ]
    },
    ssr: false
});
_c = HeadlightList;
function Home() {
    const $ = (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$compiler$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["c"])(25);
    if ($[0] !== "90a08a9cde113dc5bba70acb1cab47c9a51a9974322329ec2c517a0754eee519") {
        for(let $i = 0; $i < 25; $i += 1){
            $[$i] = Symbol.for("react.memo_cache_sentinel");
        }
        $[0] = "90a08a9cde113dc5bba70acb1cab47c9a51a9974322329ec2c517a0754eee519";
    }
    let t0;
    let t1;
    let t2;
    if ($[1] === Symbol.for("react.memo_cache_sentinel")) {
        t0 = {
            opacity: 0,
            y: 40
        };
        t1 = {
            opacity: 1,
            y: 0
        };
        t2 = {
            duration: 0.8
        };
        $[1] = t0;
        $[2] = t1;
        $[3] = t2;
    } else {
        t0 = $[1];
        t1 = $[2];
        t2 = $[3];
    }
    let t3;
    let t4;
    let t5;
    if ($[4] === Symbol.for("react.memo_cache_sentinel")) {
        t3 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            src: "/car-headlight.PNG",
            alt: "Araba Far\u0131",
            width: 120,
            height: 120,
            className: "mb-4"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 45,
            columnNumber: 10
        }, this);
        t4 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
            className: "text-4xl md:text-5xl font-bold text-blue-900 dark:text-blue-200 mb-4",
            children: "Yeni ve İkinci El Araba Farı Satışı"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 46,
            columnNumber: 10
        }, this);
        t5 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-lg md:text-xl text-zinc-700 dark:text-zinc-300 max-w-2xl mb-6",
            children: "Firmam\u0131z, t\xFCm marka ve model ara\xE7lar i\xE7in orijinal ve uygun fiyatl\u0131 yeni & ikinci el far \xE7\xF6z\xFCmleri sunar. G\xFCvenli s\xFCr\xFC\u015F i\xE7in do\u011Fru far burada!"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 47,
            columnNumber: 10
        }, this);
        $[4] = t3;
        $[5] = t4;
        $[6] = t5;
    } else {
        t3 = $[4];
        t4 = $[5];
        t5 = $[6];
    }
    let t6;
    if ($[7] === Symbol.for("react.memo_cache_sentinel")) {
        t6 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].section, {
            initial: t0,
            animate: t1,
            transition: t2,
            className: "w-full flex flex-col items-center text-center mb-16",
            children: [
                t3,
                t4,
                t5,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].a, {
                    whileHover: {
                        scale: 1.05
                    },
                    whileTap: {
                        scale: 0.97
                    },
                    href: "#kategoriler",
                    className: "inline-block px-8 py-3 rounded-full bg-blue-700 text-white font-semibold shadow-lg hover:bg-blue-800 transition",
                    children: "Ürünleri İncele"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 58,
                    columnNumber: 144
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 58,
            columnNumber: 10
        }, this);
        $[7] = t6;
    } else {
        t6 = $[7];
    }
    let t10;
    let t7;
    let t8;
    let t9;
    if ($[8] === Symbol.for("react.memo_cache_sentinel")) {
        t7 = {
            opacity: 0,
            y: 40
        };
        t8 = {
            opacity: 1,
            y: 0
        };
        t9 = {
            once: true
        };
        t10 = {
            duration: 0.7,
            delay: 0.2
        };
        $[8] = t10;
        $[9] = t7;
        $[10] = t8;
        $[11] = t9;
    } else {
        t10 = $[8];
        t7 = $[9];
        t8 = $[10];
        t9 = $[11];
    }
    let t11;
    if ($[12] === Symbol.for("react.memo_cache_sentinel")) {
        t11 = {
            scale: 1.03
        };
        $[12] = t11;
    } else {
        t11 = $[12];
    }
    let t12;
    if ($[13] === Symbol.for("react.memo_cache_sentinel")) {
        t12 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
            whileHover: t11,
            className: "rounded-xl bg-white dark:bg-zinc-900 shadow p-8 flex flex-col items-center",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    src: "/new-headlight.svg",
                    alt: "Yeni Farlar",
                    width: 80,
                    height: 80,
                    className: "mb-3 rounded"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 108,
                    columnNumber: 127
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-2xl font-bold text-blue-800 dark:text-blue-200 mb-2",
                    children: "Yeni Farlar"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 108,
                    columnNumber: 227
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-zinc-600 dark:text-zinc-300 mb-2 text-center",
                    children: "Tüm marka ve modeller için sıfır, orijinal araba farları."
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 108,
                    columnNumber: 316
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "#",
                    className: "text-blue-700 hover:underline font-medium",
                    children: "Detaylar"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 108,
                    columnNumber: 442
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 108,
            columnNumber: 11
        }, this);
        $[13] = t12;
    } else {
        t12 = $[13];
    }
    let t13;
    if ($[14] === Symbol.for("react.memo_cache_sentinel")) {
        t13 = {
            scale: 1.03
        };
        $[14] = t13;
    } else {
        t13 = $[14];
    }
    let t14;
    if ($[15] === Symbol.for("react.memo_cache_sentinel")) {
        t14 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].section, {
            id: "kategoriler",
            initial: t7,
            whileInView: t8,
            viewport: t9,
            transition: t10,
            className: "w-full grid grid-cols-1 md:grid-cols-2 gap-8 mb-20",
            children: [
                t12,
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].div, {
                    whileHover: t13,
                    className: "rounded-xl bg-white dark:bg-zinc-900 shadow p-8 flex flex-col items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$image$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            src: "/used-headlight.svg",
                            alt: "\u0130kinci El Farlar",
                            width: 80,
                            height: 80,
                            className: "mb-3 rounded"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                            lineNumber: 124,
                            columnNumber: 289
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-2xl font-bold text-blue-800 dark:text-blue-200 mb-2",
                            children: "İkinci El Farlar"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                            lineNumber: 124,
                            columnNumber: 402
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-zinc-600 dark:text-zinc-300 mb-2 text-center",
                            children: "Ekonomik ve garantili ikinci el araba farı seçenekleri."
                        }, void 0, false, {
                            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                            lineNumber: 124,
                            columnNumber: 496
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                            href: "#",
                            className: "text-blue-700 hover:underline font-medium",
                            children: "Detaylar"
                        }, void 0, false, {
                            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                            lineNumber: 124,
                            columnNumber: 620
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 124,
                    columnNumber: 173
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 124,
            columnNumber: 11
        }, this);
        $[15] = t14;
    } else {
        t14 = $[15];
    }
    let t15;
    let t16;
    let t17;
    let t18;
    if ($[16] === Symbol.for("react.memo_cache_sentinel")) {
        t15 = {
            opacity: 0,
            y: 40
        };
        t16 = {
            opacity: 1,
            y: 0
        };
        t17 = {
            once: true
        };
        t18 = {
            duration: 0.7,
            delay: 0.3
        };
        $[16] = t15;
        $[17] = t16;
        $[18] = t17;
        $[19] = t18;
    } else {
        t15 = $[16];
        t16 = $[17];
        t17 = $[18];
        t18 = $[19];
    }
    let t19;
    if ($[20] === Symbol.for("react.memo_cache_sentinel")) {
        t19 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex-1",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                    className: "text-xl font-bold text-blue-900 dark:text-blue-200 mb-2",
                    children: "Hakkımızda"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 161,
                    columnNumber: 35
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: "text-zinc-700 dark:text-zinc-300 mb-2",
                    children: "20+ yıllık tecrübemizle, müşteri memnuniyetini ön planda tutarak, hızlı kargo ve güvenli alışveriş imkanı sunuyoruz. Tüm ürünlerimiz garantilidir."
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 161,
                    columnNumber: 122
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 161,
            columnNumber: 11
        }, this);
        $[20] = t19;
    } else {
        t19 = $[20];
    }
    let t20;
    let t21;
    if ($[21] === Symbol.for("react.memo_cache_sentinel")) {
        t20 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
            className: "text-xl font-bold text-blue-900 dark:text-blue-200 mb-2",
            children: "İletişim"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 169,
            columnNumber: 11
        }, this);
        t21 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-zinc-700 dark:text-zinc-300 mb-1 font-semibold",
            children: "Halil Korkmaz"
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 170,
            columnNumber: 11
        }, this);
        $[21] = t20;
        $[22] = t21;
    } else {
        t20 = $[21];
        t21 = $[22];
    }
    let t22;
    if ($[23] === Symbol.for("react.memo_cache_sentinel")) {
        t22 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
            className: "text-zinc-700 dark:text-zinc-300 mb-1",
            children: [
                "Telefon / WhatsApp: ",
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                    href: "tel:+905326669351",
                    className: "text-blue-700",
                    children: "+90 532 666 93 51"
                }, void 0, false, {
                    fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                    lineNumber: 179,
                    columnNumber: 84
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 179,
            columnNumber: 11
        }, this);
        $[23] = t22;
    } else {
        t22 = $[23];
    }
    let t23;
    if ($[24] === Symbol.for("react.memo_cache_sentinel")) {
        t23 = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "min-h-screen bg-gradient-to-br from-blue-50 to-zinc-100 dark:from-zinc-900 dark:to-black font-sans",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                className: "flex flex-col items-center px-4 py-12 mx-auto max-w-5xl",
                children: [
                    t6,
                    t14,
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$framer$2d$motion$2f$dist$2f$es$2f$render$2f$components$2f$motion$2f$proxy$2e$mjs__$5b$app$2d$client$5d$__$28$ecmascript$29$__["motion"].section, {
                        initial: t15,
                        whileInView: t16,
                        viewport: t17,
                        transition: t18,
                        className: "w-full bg-blue-50 dark:bg-zinc-800 rounded-xl p-8 shadow flex flex-col md:flex-row items-center md:items-start gap-8",
                        children: [
                            t19,
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1",
                                children: [
                                    t20,
                                    t21,
                                    t22,
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-zinc-700 dark:text-zinc-300 mb-1",
                                        children: [
                                            "E-posta: ",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                href: "mailto:korkmazfar@gmail.com",
                                                className: "text-blue-700",
                                                children: "korkmazfar@gmail.com"
                                            }, void 0, false, {
                                                fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                                                lineNumber: 186,
                                                columnNumber: 525
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                                        lineNumber: 186,
                                        columnNumber: 463
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-zinc-700 dark:text-zinc-300",
                                        children: "Adres: Kazımdirik, 357/3. Sk. No:3, 35100 Bornova/İzmir"
                                    }, void 0, false, {
                                        fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                                        lineNumber: 186,
                                        columnNumber: 617
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                                lineNumber: 186,
                                columnNumber: 424
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                        lineNumber: 186,
                        columnNumber: 210
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$Desktop$2f$korkmazfarcom$2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(HeadlightList, {}, void 0, false, {
                        fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                        lineNumber: 186,
                        columnNumber: 747
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
                lineNumber: 186,
                columnNumber: 127
            }, this)
        }, void 0, false, {
            fileName: "[project]/Desktop/korkmazfarcom/src/app/page.tsx",
            lineNumber: 186,
            columnNumber: 11
        }, this);
        $[24] = t23;
    } else {
        t23 = $[24];
    }
    return t23;
}
_c1 = Home;
var _c, _c1;
__turbopack_context__.k.register(_c, "HeadlightList");
__turbopack_context__.k.register(_c1, "Home");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# sourceMappingURL=Desktop_korkmazfarcom_src_app_page_tsx_a1fa69a1._.js.map