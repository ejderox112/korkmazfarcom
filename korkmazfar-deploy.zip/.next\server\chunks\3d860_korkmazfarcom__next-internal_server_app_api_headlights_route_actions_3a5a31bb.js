module.exports=[9240,(e,o,d)=>{}];

//# sourceMappingURL=3d860_korkmazfarcom__next-internal_server_app_api_headlights_route_actions_3a5a31bb.js.map