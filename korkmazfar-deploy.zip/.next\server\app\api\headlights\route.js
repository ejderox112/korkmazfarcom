var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/headlights/route.js")
R.c("server/chunks/[root-of-the-server]__72b24a8b._.js")
R.c("server/chunks/[root-of-the-server]__6bcfc10c._.js")
R.c("server/chunks/3d860_korkmazfarcom__next-internal_server_app_api_headlights_route_actions_3a5a31bb.js")
R.m(28165)
module.exports=R.m(28165).exports
