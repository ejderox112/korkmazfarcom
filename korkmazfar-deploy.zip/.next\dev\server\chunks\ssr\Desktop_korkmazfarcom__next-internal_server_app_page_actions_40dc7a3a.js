module.exports = [
"[project]/Desktop/korkmazfarcom/.next-internal/server/app/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=Desktop_korkmazfarcom__next-internal_server_app_page_actions_40dc7a3a.js.map