module.exports=[55633,(a,b,c)=>{}];

//# sourceMappingURL=3d860_korkmazfarcom__next-internal_server_app__global-error_page_actions_fa600627.js.map